﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace XMX.WMS.Migrations
{
    public partial class delManyColumn1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_CompanyInfo_confirm_company_id",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_GoodsInfo_confirm_goods_id",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_QualityInfo_confirm_quality_status",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_SlotInfo_confirm_slot_code",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_WarehouseInfo_confirm_warehouse_id",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_PlatFormInfo_exporder_platform_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_PortInfo_exporder_port_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_HistoryTaskMainInfo_history_task_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_GoodsInfo_CompanyInfo_goods_company_id",
                table: "GoodsInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_GoodsInfo_UnitInfo_goods_unit",
                table: "GoodsInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_HistoryTaskMainInfo_CompanyInfo_main_company_id",
                table: "HistoryTaskMainInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_HistoryTaskMainInfo_SlotInfo_main_slot_code",
                table: "HistoryTaskMainInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_CompanyInfo_impbody_company_id",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_GoodsInfo_impbody_goods_id",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_ImportBillhead_impbody_imphead_id",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_QualityInfo_impbody_quality_status",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_WarehouseInfo_impbody_warehouse_id",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillhead_BillInfo_imphead_bill_id",
                table: "ImportBillhead");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillhead_CompanyInfo_imphead_company_id",
                table: "ImportBillhead");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_HistoryTaskMainInfo_history_task_id",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_ImportBillbody_imporder_body_id",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_CompanyInfo_imporder_company_id",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_GoodsInfo_imporder_goods_id",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_PortInfo_imporder_port_id",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_QualityInfo_imporder_quality_status",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_SlotInfo_imporder_slot_code",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_WarehouseInfo_imporder_warehouse_id",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportStock_PortInfo_impstock_port_id",
                table: "ImportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportStock_SlotInfo_impstock_slot_code",
                table: "ImportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_InventoryInfo_PortInfo_inventory_port_id",
                table: "InventoryInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_InventoryInfo_WarehouseInfo_inventory_warehouse_id",
                table: "InventoryInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_PackInfo_CompanyInfo_pack_company_id",
                table: "PackInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_PlatFormInfo_WarehouseInfo_platform_warehouse_id",
                table: "PlatFormInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_PortInfo_WarehouseInfo_port_warehouse_id",
                table: "PortInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_RowInfo_AreaInfo_row_area_id",
                table: "RowInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_RowInfo_SlotSize_row_size_id",
                table: "RowInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_RowInfo_TunnelInfo_row_tunnel_id",
                table: "RowInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_SlotInfo_SlotSize_slot_size_level",
                table: "SlotInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_SlotSize_CompanyInfo_size_company_id",
                table: "SlotSize");

            migrationBuilder.DropForeignKey(
                name: "FK_SlotSize_WarehouseInfo_size_warehouse_id",
                table: "SlotSize");

            migrationBuilder.DropForeignKey(
                name: "FK_StrategyDistribution_CompanyInfo_distribution_company_id",
                table: "StrategyDistribution");

            migrationBuilder.DropForeignKey(
                name: "FK_TunnelInfo_RowInfo_slot_row_id",
                table: "TunnelInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_TunnelPort_CompanyInfo_tunnelPort_company_id",
                table: "TunnelPort");

            migrationBuilder.DropIndex(
                name: "IX_TunnelPort_tunnelPort_company_id",
                table: "TunnelPort");

            migrationBuilder.DropIndex(
                name: "IX_SlotSize_size_company_id",
                table: "SlotSize");

            migrationBuilder.DropIndex(
                name: "IX_SlotSize_size_warehouse_id",
                table: "SlotSize");

            migrationBuilder.DropIndex(
                name: "IX_RowInfo_row_area_id",
                table: "RowInfo");

            migrationBuilder.DropIndex(
                name: "IX_RowInfo_row_size_id",
                table: "RowInfo");

            migrationBuilder.DropIndex(
                name: "IX_RowInfo_row_tunnel_id",
                table: "RowInfo");

            migrationBuilder.DropIndex(
                name: "IX_InventoryInfo_inventory_port_id",
                table: "InventoryInfo");

            migrationBuilder.DropIndex(
                name: "IX_InventoryInfo_inventory_warehouse_id",
                table: "InventoryInfo");

            migrationBuilder.DropIndex(
                name: "IX_ImportStock_impstock_port_id",
                table: "ImportStock");

            migrationBuilder.DropIndex(
                name: "IX_ImportStock_impstock_slot_code",
                table: "ImportStock");

            migrationBuilder.DropIndex(
                name: "IX_ImportOrder_history_task_id",
                table: "ImportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ImportOrder_imporder_company_id",
                table: "ImportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ImportOrder_imporder_goods_id",
                table: "ImportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ImportOrder_imporder_port_id",
                table: "ImportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ImportOrder_imporder_quality_status",
                table: "ImportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ImportOrder_imporder_slot_code",
                table: "ImportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ImportOrder_imporder_warehouse_id",
                table: "ImportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ImportBillhead_imphead_company_id",
                table: "ImportBillhead");

            migrationBuilder.DropIndex(
                name: "IX_ImportBillbody_impbody_company_id",
                table: "ImportBillbody");

            migrationBuilder.DropIndex(
                name: "IX_ImportBillbody_impbody_warehouse_id",
                table: "ImportBillbody");

            migrationBuilder.DropIndex(
                name: "IX_HistoryTaskMainInfo_main_company_id",
                table: "HistoryTaskMainInfo");

            migrationBuilder.DropIndex(
                name: "IX_GoodsInfo_goods_company_id",
                table: "GoodsInfo");

            migrationBuilder.DropIndex(
                name: "IX_ExportOrder_exporder_platform_id",
                table: "ExportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ExportOrder_exporder_port_id",
                table: "ExportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ExportOrder_history_task_id",
                table: "ExportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ExportConfirm_confirm_company_id",
                table: "ExportConfirm");

            migrationBuilder.DropIndex(
                name: "IX_ExportConfirm_confirm_warehouse_id",
                table: "ExportConfirm");

            migrationBuilder.DropColumn(
                name: "tunnelPort_company_id",
                table: "TunnelPort");

            migrationBuilder.DropColumn(
                name: "size_company_id",
                table: "SlotSize");

            migrationBuilder.DropColumn(
                name: "size_warehouse_id",
                table: "SlotSize");

            migrationBuilder.DropColumn(
                name: "row_area_id",
                table: "RowInfo");

            migrationBuilder.DropColumn(
                name: "row_size_id",
                table: "RowInfo");

            migrationBuilder.DropColumn(
                name: "row_tunnel_id",
                table: "RowInfo");

            migrationBuilder.DropColumn(
                name: "inventory_port_id",
                table: "InventoryInfo");

            migrationBuilder.DropColumn(
                name: "inventory_warehouse_id",
                table: "InventoryInfo");

            migrationBuilder.DropColumn(
                name: "impstock_port_id",
                table: "ImportStock");

            migrationBuilder.DropColumn(
                name: "impstock_slot_code",
                table: "ImportStock");

            migrationBuilder.DropColumn(
                name: "history_task_id",
                table: "ImportOrder");

            migrationBuilder.DropColumn(
                name: "imporder_company_id",
                table: "ImportOrder");

            migrationBuilder.DropColumn(
                name: "imporder_goods_id",
                table: "ImportOrder");

            migrationBuilder.DropColumn(
                name: "imporder_port_id",
                table: "ImportOrder");

            migrationBuilder.DropColumn(
                name: "imporder_quality_status",
                table: "ImportOrder");

            migrationBuilder.DropColumn(
                name: "imporder_slot_code",
                table: "ImportOrder");

            migrationBuilder.DropColumn(
                name: "imporder_warehouse_id",
                table: "ImportOrder");

            migrationBuilder.DropColumn(
                name: "imphead_company_id",
                table: "ImportBillhead");

            migrationBuilder.DropColumn(
                name: "impbody_company_id",
                table: "ImportBillbody");

            migrationBuilder.DropColumn(
                name: "impbody_warehouse_id",
                table: "ImportBillbody");

            migrationBuilder.DropColumn(
                name: "main_company_id",
                table: "HistoryTaskMainInfo");

            migrationBuilder.DropColumn(
                name: "goods_company_id",
                table: "GoodsInfo");

            migrationBuilder.DropColumn(
                name: "exporder_platform_id",
                table: "ExportOrder");

            migrationBuilder.DropColumn(
                name: "exporder_port_id",
                table: "ExportOrder");

            migrationBuilder.DropColumn(
                name: "history_task_id",
                table: "ExportOrder");

            migrationBuilder.DropColumn(
                name: "confirm_company_id",
                table: "ExportConfirm");

            migrationBuilder.DropColumn(
                name: "confirm_warehouse_id",
                table: "ExportConfirm");

            migrationBuilder.AlterColumn<Guid>(
                name: "slot_row_id",
                table: "TunnelInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "distribution_company_id",
                table: "StrategyDistribution",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "slot_size_level",
                table: "SlotInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "port_warehouse_id",
                table: "PortInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "platform_warehouse_id",
                table: "PlatFormInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "pack_company_id",
                table: "PackInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "imporder_body_id",
                table: "ImportOrder",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "imphead_bill_id",
                table: "ImportBillhead",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "impbody_quality_status",
                table: "ImportBillbody",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "impbody_imphead_id",
                table: "ImportBillbody",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "impbody_goods_id",
                table: "ImportBillbody",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "main_slot_code",
                table: "HistoryTaskMainInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "goods_unit",
                table: "GoodsInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "exporder_slot_code",
                table: "ExportOrder",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "confirm_slot_code",
                table: "ExportConfirm",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "confirm_quality_status",
                table: "ExportConfirm",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "confirm_goods_id",
                table: "ExportConfirm",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_GoodsInfo_confirm_goods_id",
                table: "ExportConfirm",
                column: "confirm_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_QualityInfo_confirm_quality_status",
                table: "ExportConfirm",
                column: "confirm_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_SlotInfo_confirm_slot_code",
                table: "ExportConfirm",
                column: "confirm_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder",
                column: "exporder_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_GoodsInfo_UnitInfo_goods_unit",
                table: "GoodsInfo",
                column: "goods_unit",
                principalTable: "UnitInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HistoryTaskMainInfo_SlotInfo_main_slot_code",
                table: "HistoryTaskMainInfo",
                column: "main_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_GoodsInfo_impbody_goods_id",
                table: "ImportBillbody",
                column: "impbody_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_ImportBillhead_impbody_imphead_id",
                table: "ImportBillbody",
                column: "impbody_imphead_id",
                principalTable: "ImportBillhead",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_QualityInfo_impbody_quality_status",
                table: "ImportBillbody",
                column: "impbody_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillhead_BillInfo_imphead_bill_id",
                table: "ImportBillhead",
                column: "imphead_bill_id",
                principalTable: "BillInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_ImportBillbody_imporder_body_id",
                table: "ImportOrder",
                column: "imporder_body_id",
                principalTable: "ImportBillbody",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_PackInfo_CompanyInfo_pack_company_id",
                table: "PackInfo",
                column: "pack_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_PlatFormInfo_WarehouseInfo_platform_warehouse_id",
                table: "PlatFormInfo",
                column: "platform_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_PortInfo_WarehouseInfo_port_warehouse_id",
                table: "PortInfo",
                column: "port_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SlotInfo_SlotSize_slot_size_level",
                table: "SlotInfo",
                column: "slot_size_level",
                principalTable: "SlotSize",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StrategyDistribution_CompanyInfo_distribution_company_id",
                table: "StrategyDistribution",
                column: "distribution_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TunnelInfo_RowInfo_slot_row_id",
                table: "TunnelInfo",
                column: "slot_row_id",
                principalTable: "RowInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_GoodsInfo_confirm_goods_id",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_QualityInfo_confirm_quality_status",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportConfirm_SlotInfo_confirm_slot_code",
                table: "ExportConfirm");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_GoodsInfo_UnitInfo_goods_unit",
                table: "GoodsInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_HistoryTaskMainInfo_SlotInfo_main_slot_code",
                table: "HistoryTaskMainInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_GoodsInfo_impbody_goods_id",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_ImportBillhead_impbody_imphead_id",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillbody_QualityInfo_impbody_quality_status",
                table: "ImportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportBillhead_BillInfo_imphead_bill_id",
                table: "ImportBillhead");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportOrder_ImportBillbody_imporder_body_id",
                table: "ImportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_PackInfo_CompanyInfo_pack_company_id",
                table: "PackInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_PlatFormInfo_WarehouseInfo_platform_warehouse_id",
                table: "PlatFormInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_PortInfo_WarehouseInfo_port_warehouse_id",
                table: "PortInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_SlotInfo_SlotSize_slot_size_level",
                table: "SlotInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_StrategyDistribution_CompanyInfo_distribution_company_id",
                table: "StrategyDistribution");

            migrationBuilder.DropForeignKey(
                name: "FK_TunnelInfo_RowInfo_slot_row_id",
                table: "TunnelInfo");

            migrationBuilder.AddColumn<Guid>(
                name: "tunnelPort_company_id",
                table: "TunnelPort",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "slot_row_id",
                table: "TunnelInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "distribution_company_id",
                table: "StrategyDistribution",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "size_company_id",
                table: "SlotSize",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "size_warehouse_id",
                table: "SlotSize",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "slot_size_level",
                table: "SlotInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "row_area_id",
                table: "RowInfo",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "row_size_id",
                table: "RowInfo",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "row_tunnel_id",
                table: "RowInfo",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AlterColumn<Guid>(
                name: "port_warehouse_id",
                table: "PortInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "platform_warehouse_id",
                table: "PlatFormInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "pack_company_id",
                table: "PackInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "inventory_port_id",
                table: "InventoryInfo",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "inventory_warehouse_id",
                table: "InventoryInfo",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "impstock_port_id",
                table: "ImportStock",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "impstock_slot_code",
                table: "ImportStock",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "imporder_body_id",
                table: "ImportOrder",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "history_task_id",
                table: "ImportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "imporder_company_id",
                table: "ImportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "imporder_goods_id",
                table: "ImportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "imporder_port_id",
                table: "ImportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "imporder_quality_status",
                table: "ImportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "imporder_slot_code",
                table: "ImportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "imporder_warehouse_id",
                table: "ImportOrder",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "imphead_bill_id",
                table: "ImportBillhead",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "imphead_company_id",
                table: "ImportBillhead",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "impbody_quality_status",
                table: "ImportBillbody",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "impbody_imphead_id",
                table: "ImportBillbody",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "impbody_goods_id",
                table: "ImportBillbody",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "impbody_company_id",
                table: "ImportBillbody",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "impbody_warehouse_id",
                table: "ImportBillbody",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "main_slot_code",
                table: "HistoryTaskMainInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "main_company_id",
                table: "HistoryTaskMainInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "goods_unit",
                table: "GoodsInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "goods_company_id",
                table: "GoodsInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "exporder_slot_code",
                table: "ExportOrder",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "exporder_platform_id",
                table: "ExportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "exporder_port_id",
                table: "ExportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "history_task_id",
                table: "ExportOrder",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "confirm_slot_code",
                table: "ExportConfirm",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "confirm_quality_status",
                table: "ExportConfirm",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "confirm_goods_id",
                table: "ExportConfirm",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "confirm_company_id",
                table: "ExportConfirm",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "confirm_warehouse_id",
                table: "ExportConfirm",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_TunnelPort_tunnelPort_company_id",
                table: "TunnelPort",
                column: "tunnelPort_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_SlotSize_size_company_id",
                table: "SlotSize",
                column: "size_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_SlotSize_size_warehouse_id",
                table: "SlotSize",
                column: "size_warehouse_id");

            migrationBuilder.CreateIndex(
                name: "IX_RowInfo_row_area_id",
                table: "RowInfo",
                column: "row_area_id");

            migrationBuilder.CreateIndex(
                name: "IX_RowInfo_row_size_id",
                table: "RowInfo",
                column: "row_size_id");

            migrationBuilder.CreateIndex(
                name: "IX_RowInfo_row_tunnel_id",
                table: "RowInfo",
                column: "row_tunnel_id");

            migrationBuilder.CreateIndex(
                name: "IX_InventoryInfo_inventory_port_id",
                table: "InventoryInfo",
                column: "inventory_port_id");

            migrationBuilder.CreateIndex(
                name: "IX_InventoryInfo_inventory_warehouse_id",
                table: "InventoryInfo",
                column: "inventory_warehouse_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportStock_impstock_port_id",
                table: "ImportStock",
                column: "impstock_port_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportStock_impstock_slot_code",
                table: "ImportStock",
                column: "impstock_slot_code");

            migrationBuilder.CreateIndex(
                name: "IX_ImportOrder_history_task_id",
                table: "ImportOrder",
                column: "history_task_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportOrder_imporder_company_id",
                table: "ImportOrder",
                column: "imporder_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportOrder_imporder_goods_id",
                table: "ImportOrder",
                column: "imporder_goods_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportOrder_imporder_port_id",
                table: "ImportOrder",
                column: "imporder_port_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportOrder_imporder_quality_status",
                table: "ImportOrder",
                column: "imporder_quality_status");

            migrationBuilder.CreateIndex(
                name: "IX_ImportOrder_imporder_slot_code",
                table: "ImportOrder",
                column: "imporder_slot_code");

            migrationBuilder.CreateIndex(
                name: "IX_ImportOrder_imporder_warehouse_id",
                table: "ImportOrder",
                column: "imporder_warehouse_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportBillhead_imphead_company_id",
                table: "ImportBillhead",
                column: "imphead_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportBillbody_impbody_company_id",
                table: "ImportBillbody",
                column: "impbody_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ImportBillbody_impbody_warehouse_id",
                table: "ImportBillbody",
                column: "impbody_warehouse_id");

            migrationBuilder.CreateIndex(
                name: "IX_HistoryTaskMainInfo_main_company_id",
                table: "HistoryTaskMainInfo",
                column: "main_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_GoodsInfo_goods_company_id",
                table: "GoodsInfo",
                column: "goods_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportOrder_exporder_platform_id",
                table: "ExportOrder",
                column: "exporder_platform_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportOrder_exporder_port_id",
                table: "ExportOrder",
                column: "exporder_port_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportOrder_history_task_id",
                table: "ExportOrder",
                column: "history_task_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportConfirm_confirm_company_id",
                table: "ExportConfirm",
                column: "confirm_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportConfirm_confirm_warehouse_id",
                table: "ExportConfirm",
                column: "confirm_warehouse_id");

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_CompanyInfo_confirm_company_id",
                table: "ExportConfirm",
                column: "confirm_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_GoodsInfo_confirm_goods_id",
                table: "ExportConfirm",
                column: "confirm_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_QualityInfo_confirm_quality_status",
                table: "ExportConfirm",
                column: "confirm_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_SlotInfo_confirm_slot_code",
                table: "ExportConfirm",
                column: "confirm_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportConfirm_WarehouseInfo_confirm_warehouse_id",
                table: "ExportConfirm",
                column: "confirm_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_PlatFormInfo_exporder_platform_id",
                table: "ExportOrder",
                column: "exporder_platform_id",
                principalTable: "PlatFormInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_PortInfo_exporder_port_id",
                table: "ExportOrder",
                column: "exporder_port_id",
                principalTable: "PortInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder",
                column: "exporder_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_HistoryTaskMainInfo_history_task_id",
                table: "ExportOrder",
                column: "history_task_id",
                principalTable: "HistoryTaskMainInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_GoodsInfo_CompanyInfo_goods_company_id",
                table: "GoodsInfo",
                column: "goods_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_GoodsInfo_UnitInfo_goods_unit",
                table: "GoodsInfo",
                column: "goods_unit",
                principalTable: "UnitInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_HistoryTaskMainInfo_CompanyInfo_main_company_id",
                table: "HistoryTaskMainInfo",
                column: "main_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_HistoryTaskMainInfo_SlotInfo_main_slot_code",
                table: "HistoryTaskMainInfo",
                column: "main_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_CompanyInfo_impbody_company_id",
                table: "ImportBillbody",
                column: "impbody_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_GoodsInfo_impbody_goods_id",
                table: "ImportBillbody",
                column: "impbody_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_ImportBillhead_impbody_imphead_id",
                table: "ImportBillbody",
                column: "impbody_imphead_id",
                principalTable: "ImportBillhead",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_QualityInfo_impbody_quality_status",
                table: "ImportBillbody",
                column: "impbody_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillbody_WarehouseInfo_impbody_warehouse_id",
                table: "ImportBillbody",
                column: "impbody_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillhead_BillInfo_imphead_bill_id",
                table: "ImportBillhead",
                column: "imphead_bill_id",
                principalTable: "BillInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportBillhead_CompanyInfo_imphead_company_id",
                table: "ImportBillhead",
                column: "imphead_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_HistoryTaskMainInfo_history_task_id",
                table: "ImportOrder",
                column: "history_task_id",
                principalTable: "HistoryTaskMainInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_ImportBillbody_imporder_body_id",
                table: "ImportOrder",
                column: "imporder_body_id",
                principalTable: "ImportBillbody",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_CompanyInfo_imporder_company_id",
                table: "ImportOrder",
                column: "imporder_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_GoodsInfo_imporder_goods_id",
                table: "ImportOrder",
                column: "imporder_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_PortInfo_imporder_port_id",
                table: "ImportOrder",
                column: "imporder_port_id",
                principalTable: "PortInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_QualityInfo_imporder_quality_status",
                table: "ImportOrder",
                column: "imporder_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_SlotInfo_imporder_slot_code",
                table: "ImportOrder",
                column: "imporder_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportOrder_WarehouseInfo_imporder_warehouse_id",
                table: "ImportOrder",
                column: "imporder_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportStock_PortInfo_impstock_port_id",
                table: "ImportStock",
                column: "impstock_port_id",
                principalTable: "PortInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportStock_SlotInfo_impstock_slot_code",
                table: "ImportStock",
                column: "impstock_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_InventoryInfo_PortInfo_inventory_port_id",
                table: "InventoryInfo",
                column: "inventory_port_id",
                principalTable: "PortInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_InventoryInfo_WarehouseInfo_inventory_warehouse_id",
                table: "InventoryInfo",
                column: "inventory_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_PackInfo_CompanyInfo_pack_company_id",
                table: "PackInfo",
                column: "pack_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PlatFormInfo_WarehouseInfo_platform_warehouse_id",
                table: "PlatFormInfo",
                column: "platform_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PortInfo_WarehouseInfo_port_warehouse_id",
                table: "PortInfo",
                column: "port_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RowInfo_AreaInfo_row_area_id",
                table: "RowInfo",
                column: "row_area_id",
                principalTable: "AreaInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RowInfo_SlotSize_row_size_id",
                table: "RowInfo",
                column: "row_size_id",
                principalTable: "SlotSize",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RowInfo_TunnelInfo_row_tunnel_id",
                table: "RowInfo",
                column: "row_tunnel_id",
                principalTable: "TunnelInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SlotInfo_SlotSize_slot_size_level",
                table: "SlotInfo",
                column: "slot_size_level",
                principalTable: "SlotSize",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SlotSize_CompanyInfo_size_company_id",
                table: "SlotSize",
                column: "size_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SlotSize_WarehouseInfo_size_warehouse_id",
                table: "SlotSize",
                column: "size_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_StrategyDistribution_CompanyInfo_distribution_company_id",
                table: "StrategyDistribution",
                column: "distribution_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TunnelInfo_RowInfo_slot_row_id",
                table: "TunnelInfo",
                column: "slot_row_id",
                principalTable: "RowInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TunnelPort_CompanyInfo_tunnelPort_company_id",
                table: "TunnelPort",
                column: "tunnelPort_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
