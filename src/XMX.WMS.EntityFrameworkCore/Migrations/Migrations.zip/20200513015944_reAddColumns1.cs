﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace XMX.WMS.Migrations
{
    public partial class reAddColumns1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Alarm_GoodsInfo_goods_id",
                table: "Alarm");

            migrationBuilder.DropForeignKey(
                name: "FK_AreaInfo_WarehouseInfo_area_warehouse_id",
                table: "AreaInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_BillInfo_CompanyInfo_bill_company_id",
                table: "BillInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_CustomInfo_CustomTypeInfo_custom_type_id",
                table: "CustomInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_CustomTypeInfo_CompanyInfo_customtype_company_id",
                table: "CustomTypeInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_EncodingRule_CompanyInfo_code_company_id",
                table: "EncodingRule");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_RowInfo_TunnelInfo_row_tunnel_id",
            //    table: "RowInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_RowInfo_WarehouseInfo_row_warehouse_id",
                table: "RowInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTasking_WarehouseInfo_task_warehouse_id",
                table: "StockTasking");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTaskingDetail_StockTasking_stock_tasking_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTaskingDetail_GoodsInfo_task_goods_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTaskingDetail_SlotInfo_task_slot_id",
                table: "StockTaskingDetail");

            //migrationBuilder.DropIndex(
            //    name: "IX_RowInfo_row_tunnel_id",
            //    table: "RowInfo");

            //migrationBuilder.DropColumn(
            //    name: "row_tunnel_id",
            //    table: "RowInfo");

            migrationBuilder.AddColumn<Guid>(
                name: "tunnel_company_id",
                table: "TunnelInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "task_slot_id",
                table: "StockTaskingDetail",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "task_goods_id",
                table: "StockTaskingDetail",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "stock_tasking_id",
                table: "StockTaskingDetail",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "task_company_id",
                table: "StockTaskingDetail",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "task_warehouse_id",
                table: "StockTasking",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "task_company_id",
                table: "StockTasking",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "slot_company_id",
                table: "SlotInfo",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "slot_tunnel_id",
                table: "SlotInfo",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "slot_warehouse_id",
                table: "SlotInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "row_warehouse_id",
                table: "RowInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "row_company_id",
                table: "RowInfo",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "port_company_id",
                table: "PortInfo",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "platform_company_id",
                table: "PlatFormInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "code_company_id",
                table: "EncodingRule",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "customtype_company_id",
                table: "CustomTypeInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "custom_type_id",
                table: "CustomInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "custom_company_id",
                table: "CustomInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "bill_company_id",
                table: "BillInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "bill_rule_id",
                table: "BillInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "area_warehouse_id",
                table: "AreaInfo",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "area_company_id",
                table: "AreaInfo",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "goods_id",
                table: "Alarm",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "company_id",
                table: "Alarm",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_TunnelInfo_tunnel_company_id",
                table: "TunnelInfo",
                column: "tunnel_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_StockTaskingDetail_task_company_id",
                table: "StockTaskingDetail",
                column: "task_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_StockTasking_task_company_id",
                table: "StockTasking",
                column: "task_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_SlotInfo_slot_company_id",
                table: "SlotInfo",
                column: "slot_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_SlotInfo_slot_tunnel_id",
                table: "SlotInfo",
                column: "slot_tunnel_id");

            migrationBuilder.CreateIndex(
                name: "IX_SlotInfo_slot_warehouse_id",
                table: "SlotInfo",
                column: "slot_warehouse_id");

            migrationBuilder.CreateIndex(
                name: "IX_RowInfo_row_company_id",
                table: "RowInfo",
                column: "row_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_PortInfo_port_company_id",
                table: "PortInfo",
                column: "port_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlatFormInfo_platform_company_id",
                table: "PlatFormInfo",
                column: "platform_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_CustomInfo_custom_company_id",
                table: "CustomInfo",
                column: "custom_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_BillInfo_bill_rule_id",
                table: "BillInfo",
                column: "bill_rule_id");

            migrationBuilder.CreateIndex(
                name: "IX_AreaInfo_area_company_id",
                table: "AreaInfo",
                column: "area_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_Alarm_company_id",
                table: "Alarm",
                column: "company_id");

            migrationBuilder.AddForeignKey(
                name: "FK_Alarm_CompanyInfo_company_id",
                table: "Alarm",
                column: "company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Alarm_GoodsInfo_goods_id",
                table: "Alarm",
                column: "goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_AreaInfo_CompanyInfo_area_company_id",
                table: "AreaInfo",
                column: "area_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_AreaInfo_WarehouseInfo_area_warehouse_id",
                table: "AreaInfo",
                column: "area_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_BillInfo_CompanyInfo_bill_company_id",
                table: "BillInfo",
                column: "bill_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_BillInfo_EncodingRule_bill_rule_id",
                table: "BillInfo",
                column: "bill_rule_id",
                principalTable: "EncodingRule",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CustomInfo_CompanyInfo_custom_company_id",
                table: "CustomInfo",
                column: "custom_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CustomInfo_CustomTypeInfo_custom_type_id",
                table: "CustomInfo",
                column: "custom_type_id",
                principalTable: "CustomTypeInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CustomTypeInfo_CompanyInfo_customtype_company_id",
                table: "CustomTypeInfo",
                column: "customtype_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_EncodingRule_CompanyInfo_code_company_id",
                table: "EncodingRule",
                column: "code_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PlatFormInfo_CompanyInfo_platform_company_id",
                table: "PlatFormInfo",
                column: "platform_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PortInfo_CompanyInfo_port_company_id",
                table: "PortInfo",
                column: "port_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RowInfo_CompanyInfo_row_company_id",
                table: "RowInfo",
                column: "row_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_RowInfo_WarehouseInfo_row_warehouse_id",
                table: "RowInfo",
                column: "row_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SlotInfo_CompanyInfo_slot_company_id",
                table: "SlotInfo",
                column: "slot_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SlotInfo_TunnelInfo_slot_tunnel_id",
                table: "SlotInfo",
                column: "slot_tunnel_id",
                principalTable: "TunnelInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SlotInfo_WarehouseInfo_slot_warehouse_id",
                table: "SlotInfo",
                column: "slot_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTasking_CompanyInfo_task_company_id",
                table: "StockTasking",
                column: "task_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTasking_WarehouseInfo_task_warehouse_id",
                table: "StockTasking",
                column: "task_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTaskingDetail_StockTasking_stock_tasking_id",
                table: "StockTaskingDetail",
                column: "stock_tasking_id",
                principalTable: "StockTasking",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTaskingDetail_CompanyInfo_task_company_id",
                table: "StockTaskingDetail",
                column: "task_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTaskingDetail_GoodsInfo_task_goods_id",
                table: "StockTaskingDetail",
                column: "task_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTaskingDetail_SlotInfo_task_slot_id",
                table: "StockTaskingDetail",
                column: "task_slot_id",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TunnelInfo_CompanyInfo_tunnel_company_id",
                table: "TunnelInfo",
                column: "tunnel_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Alarm_CompanyInfo_company_id",
                table: "Alarm");

            migrationBuilder.DropForeignKey(
                name: "FK_Alarm_GoodsInfo_goods_id",
                table: "Alarm");

            migrationBuilder.DropForeignKey(
                name: "FK_AreaInfo_CompanyInfo_area_company_id",
                table: "AreaInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_AreaInfo_WarehouseInfo_area_warehouse_id",
                table: "AreaInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_BillInfo_CompanyInfo_bill_company_id",
                table: "BillInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_BillInfo_EncodingRule_bill_rule_id",
                table: "BillInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_CustomInfo_CompanyInfo_custom_company_id",
                table: "CustomInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_CustomInfo_CustomTypeInfo_custom_type_id",
                table: "CustomInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_CustomTypeInfo_CompanyInfo_customtype_company_id",
                table: "CustomTypeInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_EncodingRule_CompanyInfo_code_company_id",
                table: "EncodingRule");

            migrationBuilder.DropForeignKey(
                name: "FK_PlatFormInfo_CompanyInfo_platform_company_id",
                table: "PlatFormInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_PortInfo_CompanyInfo_port_company_id",
                table: "PortInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_RowInfo_CompanyInfo_row_company_id",
                table: "RowInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_RowInfo_WarehouseInfo_row_warehouse_id",
                table: "RowInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_SlotInfo_CompanyInfo_slot_company_id",
                table: "SlotInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_SlotInfo_TunnelInfo_slot_tunnel_id",
                table: "SlotInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_SlotInfo_WarehouseInfo_slot_warehouse_id",
                table: "SlotInfo");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTasking_CompanyInfo_task_company_id",
                table: "StockTasking");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTasking_WarehouseInfo_task_warehouse_id",
                table: "StockTasking");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTaskingDetail_StockTasking_stock_tasking_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTaskingDetail_CompanyInfo_task_company_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTaskingDetail_GoodsInfo_task_goods_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTaskingDetail_SlotInfo_task_slot_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropForeignKey(
                name: "FK_TunnelInfo_CompanyInfo_tunnel_company_id",
                table: "TunnelInfo");

            migrationBuilder.DropIndex(
                name: "IX_TunnelInfo_tunnel_company_id",
                table: "TunnelInfo");

            migrationBuilder.DropIndex(
                name: "IX_StockTaskingDetail_task_company_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropIndex(
                name: "IX_StockTasking_task_company_id",
                table: "StockTasking");

            migrationBuilder.DropIndex(
                name: "IX_SlotInfo_slot_company_id",
                table: "SlotInfo");

            migrationBuilder.DropIndex(
                name: "IX_SlotInfo_slot_tunnel_id",
                table: "SlotInfo");

            migrationBuilder.DropIndex(
                name: "IX_SlotInfo_slot_warehouse_id",
                table: "SlotInfo");

            migrationBuilder.DropIndex(
                name: "IX_RowInfo_row_company_id",
                table: "RowInfo");

            migrationBuilder.DropIndex(
                name: "IX_PortInfo_port_company_id",
                table: "PortInfo");

            migrationBuilder.DropIndex(
                name: "IX_PlatFormInfo_platform_company_id",
                table: "PlatFormInfo");

            migrationBuilder.DropIndex(
                name: "IX_CustomInfo_custom_company_id",
                table: "CustomInfo");

            migrationBuilder.DropIndex(
                name: "IX_BillInfo_bill_rule_id",
                table: "BillInfo");

            migrationBuilder.DropIndex(
                name: "IX_AreaInfo_area_company_id",
                table: "AreaInfo");

            migrationBuilder.DropIndex(
                name: "IX_Alarm_company_id",
                table: "Alarm");

            migrationBuilder.DropColumn(
                name: "tunnel_company_id",
                table: "TunnelInfo");

            migrationBuilder.DropColumn(
                name: "task_company_id",
                table: "StockTaskingDetail");

            migrationBuilder.DropColumn(
                name: "task_company_id",
                table: "StockTasking");

            migrationBuilder.DropColumn(
                name: "slot_company_id",
                table: "SlotInfo");

            migrationBuilder.DropColumn(
                name: "slot_tunnel_id",
                table: "SlotInfo");

            migrationBuilder.DropColumn(
                name: "slot_warehouse_id",
                table: "SlotInfo");

            migrationBuilder.DropColumn(
                name: "row_company_id",
                table: "RowInfo");

            migrationBuilder.DropColumn(
                name: "port_company_id",
                table: "PortInfo");

            migrationBuilder.DropColumn(
                name: "platform_company_id",
                table: "PlatFormInfo");

            migrationBuilder.DropColumn(
                name: "custom_company_id",
                table: "CustomInfo");

            migrationBuilder.DropColumn(
                name: "bill_rule_id",
                table: "BillInfo");

            migrationBuilder.DropColumn(
                name: "area_company_id",
                table: "AreaInfo");

            migrationBuilder.DropColumn(
                name: "company_id",
                table: "Alarm");

            migrationBuilder.AlterColumn<Guid>(
                name: "task_slot_id",
                table: "StockTaskingDetail",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "task_goods_id",
                table: "StockTaskingDetail",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "stock_tasking_id",
                table: "StockTaskingDetail",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "task_warehouse_id",
                table: "StockTasking",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "row_warehouse_id",
                table: "RowInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "row_tunnel_id",
                table: "RowInfo",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AlterColumn<Guid>(
                name: "code_company_id",
                table: "EncodingRule",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "customtype_company_id",
                table: "CustomTypeInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "custom_type_id",
                table: "CustomInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "bill_company_id",
                table: "BillInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "area_warehouse_id",
                table: "AreaInfo",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "goods_id",
                table: "Alarm",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_RowInfo_row_tunnel_id",
                table: "RowInfo",
                column: "row_tunnel_id");

            migrationBuilder.AddForeignKey(
                name: "FK_Alarm_GoodsInfo_goods_id",
                table: "Alarm",
                column: "goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AreaInfo_WarehouseInfo_area_warehouse_id",
                table: "AreaInfo",
                column: "area_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_BillInfo_CompanyInfo_bill_company_id",
                table: "BillInfo",
                column: "bill_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CustomInfo_CustomTypeInfo_custom_type_id",
                table: "CustomInfo",
                column: "custom_type_id",
                principalTable: "CustomTypeInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CustomTypeInfo_CompanyInfo_customtype_company_id",
                table: "CustomTypeInfo",
                column: "customtype_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_EncodingRule_CompanyInfo_code_company_id",
                table: "EncodingRule",
                column: "code_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            //migrationBuilder.AddForeignKey(
            //    name: "FK_RowInfo_TunnelInfo_row_tunnel_id",
            //    table: "RowInfo",
            //    column: "row_tunnel_id",
            //    principalTable: "TunnelInfo",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_RowInfo_WarehouseInfo_row_warehouse_id",
                table: "RowInfo",
                column: "row_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTasking_WarehouseInfo_task_warehouse_id",
                table: "StockTasking",
                column: "task_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTaskingDetail_StockTasking_stock_tasking_id",
                table: "StockTaskingDetail",
                column: "stock_tasking_id",
                principalTable: "StockTasking",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTaskingDetail_GoodsInfo_task_goods_id",
                table: "StockTaskingDetail",
                column: "task_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTaskingDetail_SlotInfo_task_slot_id",
                table: "StockTaskingDetail",
                column: "task_slot_id",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
