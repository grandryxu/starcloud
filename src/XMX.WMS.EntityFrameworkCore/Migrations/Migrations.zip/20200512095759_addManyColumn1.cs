﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace XMX.WMS.Migrations
{
    public partial class addManyColumn1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillbody_GoodsInfo_expbody_goods_id",
                table: "ExportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillbody_ExportBillhead_expbody_imphead_id",
                table: "ExportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillbody_QualityInfo_expbody_quality_status",
                table: "ExportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillhead_BillInfo_exphead_bill_id",
                table: "ExportBillhead");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_ExportBillbody_exporder_body_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportStock_GoodsInfo_expstock_goods_id",
                table: "ExportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportStock_SlotInfo_expstock_slot_code",
                table: "ExportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportStock_WarehouseInfo_expstock_warehouse_id",
                table: "ExportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportStock_GoodsInfo_impstock_goods_id",
                table: "ImportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportStock_WarehouseInfo_impstock_warehouse_id",
                table: "ImportStock");

            migrationBuilder.AlterColumn<Guid>(
                name: "impstock_warehouse_id",
                table: "ImportStock",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "impstock_goods_id",
                table: "ImportStock",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "impstock_company_id",
                table: "ImportStock",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expstock_warehouse_id",
                table: "ExportStock",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "expstock_slot_code",
                table: "ExportStock",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "expstock_goods_id",
                table: "ExportStock",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "expstock_company_id",
                table: "ExportStock",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "exporder_slot_code",
                table: "ExportOrder",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "exporder_body_id",
                table: "ExportOrder",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "exporder_company_id",
                table: "ExportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "exporder_goods_id",
                table: "ExportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "exporder_quality_status",
                table: "ExportOrder",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "exporder_warehouse_id",
                table: "ExportOrder",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "exphead_bill_id",
                table: "ExportBillhead",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "exphead_company_id",
                table: "ExportBillhead",
                nullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expbody_quality_status",
                table: "ExportBillbody",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "expbody_imphead_id",
                table: "ExportBillbody",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AlterColumn<Guid>(
                name: "expbody_goods_id",
                table: "ExportBillbody",
                nullable: true,
                oldClrType: typeof(Guid));

            migrationBuilder.AddColumn<Guid>(
                name: "expbody_company_id",
                table: "ExportBillbody",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ImportStock_impstock_company_id",
                table: "ImportStock",
                column: "impstock_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportStock_expstock_company_id",
                table: "ExportStock",
                column: "expstock_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportOrder_exporder_company_id",
                table: "ExportOrder",
                column: "exporder_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportOrder_exporder_goods_id",
                table: "ExportOrder",
                column: "exporder_goods_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportOrder_exporder_quality_status",
                table: "ExportOrder",
                column: "exporder_quality_status");

            migrationBuilder.CreateIndex(
                name: "IX_ExportOrder_exporder_warehouse_id",
                table: "ExportOrder",
                column: "exporder_warehouse_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportBillhead_exphead_company_id",
                table: "ExportBillhead",
                column: "exphead_company_id");

            migrationBuilder.CreateIndex(
                name: "IX_ExportBillbody_expbody_company_id",
                table: "ExportBillbody",
                column: "expbody_company_id");

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillbody_CompanyInfo_expbody_company_id",
                table: "ExportBillbody",
                column: "expbody_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillbody_GoodsInfo_expbody_goods_id",
                table: "ExportBillbody",
                column: "expbody_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillbody_ExportBillhead_expbody_imphead_id",
                table: "ExportBillbody",
                column: "expbody_imphead_id",
                principalTable: "ExportBillhead",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillbody_QualityInfo_expbody_quality_status",
                table: "ExportBillbody",
                column: "expbody_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillhead_BillInfo_exphead_bill_id",
                table: "ExportBillhead",
                column: "exphead_bill_id",
                principalTable: "BillInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillhead_CompanyInfo_exphead_company_id",
                table: "ExportBillhead",
                column: "exphead_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_ExportBillbody_exporder_body_id",
                table: "ExportOrder",
                column: "exporder_body_id",
                principalTable: "ExportBillbody",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_CompanyInfo_exporder_company_id",
                table: "ExportOrder",
                column: "exporder_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_GoodsInfo_exporder_goods_id",
                table: "ExportOrder",
                column: "exporder_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_QualityInfo_exporder_quality_status",
                table: "ExportOrder",
                column: "exporder_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder",
                column: "exporder_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_WarehouseInfo_exporder_warehouse_id",
                table: "ExportOrder",
                column: "exporder_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportStock_CompanyInfo_expstock_company_id",
                table: "ExportStock",
                column: "expstock_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportStock_GoodsInfo_expstock_goods_id",
                table: "ExportStock",
                column: "expstock_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportStock_SlotInfo_expstock_slot_code",
                table: "ExportStock",
                column: "expstock_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportStock_WarehouseInfo_expstock_warehouse_id",
                table: "ExportStock",
                column: "expstock_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportStock_CompanyInfo_impstock_company_id",
                table: "ImportStock",
                column: "impstock_company_id",
                principalTable: "CompanyInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportStock_GoodsInfo_impstock_goods_id",
                table: "ImportStock",
                column: "impstock_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportStock_WarehouseInfo_impstock_warehouse_id",
                table: "ImportStock",
                column: "impstock_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillbody_CompanyInfo_expbody_company_id",
                table: "ExportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillbody_GoodsInfo_expbody_goods_id",
                table: "ExportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillbody_ExportBillhead_expbody_imphead_id",
                table: "ExportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillbody_QualityInfo_expbody_quality_status",
                table: "ExportBillbody");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillhead_BillInfo_exphead_bill_id",
                table: "ExportBillhead");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportBillhead_CompanyInfo_exphead_company_id",
                table: "ExportBillhead");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_ExportBillbody_exporder_body_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_CompanyInfo_exporder_company_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_GoodsInfo_exporder_goods_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_QualityInfo_exporder_quality_status",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportOrder_WarehouseInfo_exporder_warehouse_id",
                table: "ExportOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportStock_CompanyInfo_expstock_company_id",
                table: "ExportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportStock_GoodsInfo_expstock_goods_id",
                table: "ExportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportStock_SlotInfo_expstock_slot_code",
                table: "ExportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ExportStock_WarehouseInfo_expstock_warehouse_id",
                table: "ExportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportStock_CompanyInfo_impstock_company_id",
                table: "ImportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportStock_GoodsInfo_impstock_goods_id",
                table: "ImportStock");

            migrationBuilder.DropForeignKey(
                name: "FK_ImportStock_WarehouseInfo_impstock_warehouse_id",
                table: "ImportStock");

            migrationBuilder.DropIndex(
                name: "IX_ImportStock_impstock_company_id",
                table: "ImportStock");

            migrationBuilder.DropIndex(
                name: "IX_ExportStock_expstock_company_id",
                table: "ExportStock");

            migrationBuilder.DropIndex(
                name: "IX_ExportOrder_exporder_company_id",
                table: "ExportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ExportOrder_exporder_goods_id",
                table: "ExportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ExportOrder_exporder_quality_status",
                table: "ExportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ExportOrder_exporder_warehouse_id",
                table: "ExportOrder");

            migrationBuilder.DropIndex(
                name: "IX_ExportBillhead_exphead_company_id",
                table: "ExportBillhead");

            migrationBuilder.DropIndex(
                name: "IX_ExportBillbody_expbody_company_id",
                table: "ExportBillbody");

            migrationBuilder.DropColumn(
                name: "impstock_company_id",
                table: "ImportStock");

            migrationBuilder.DropColumn(
                name: "expstock_company_id",
                table: "ExportStock");

            migrationBuilder.DropColumn(
                name: "exporder_company_id",
                table: "ExportOrder");

            migrationBuilder.DropColumn(
                name: "exporder_goods_id",
                table: "ExportOrder");

            migrationBuilder.DropColumn(
                name: "exporder_quality_status",
                table: "ExportOrder");

            migrationBuilder.DropColumn(
                name: "exporder_warehouse_id",
                table: "ExportOrder");

            migrationBuilder.DropColumn(
                name: "exphead_company_id",
                table: "ExportBillhead");

            migrationBuilder.DropColumn(
                name: "expbody_company_id",
                table: "ExportBillbody");

            migrationBuilder.AlterColumn<Guid>(
                name: "impstock_warehouse_id",
                table: "ImportStock",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "impstock_goods_id",
                table: "ImportStock",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expstock_warehouse_id",
                table: "ExportStock",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expstock_slot_code",
                table: "ExportStock",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expstock_goods_id",
                table: "ExportStock",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "exporder_slot_code",
                table: "ExportOrder",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "exporder_body_id",
                table: "ExportOrder",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "exphead_bill_id",
                table: "ExportBillhead",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expbody_quality_status",
                table: "ExportBillbody",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expbody_imphead_id",
                table: "ExportBillbody",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AlterColumn<Guid>(
                name: "expbody_goods_id",
                table: "ExportBillbody",
                nullable: false,
                oldClrType: typeof(Guid),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillbody_GoodsInfo_expbody_goods_id",
                table: "ExportBillbody",
                column: "expbody_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillbody_ExportBillhead_expbody_imphead_id",
                table: "ExportBillbody",
                column: "expbody_imphead_id",
                principalTable: "ExportBillhead",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillbody_QualityInfo_expbody_quality_status",
                table: "ExportBillbody",
                column: "expbody_quality_status",
                principalTable: "QualityInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportBillhead_BillInfo_exphead_bill_id",
                table: "ExportBillhead",
                column: "exphead_bill_id",
                principalTable: "BillInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_ExportBillbody_exporder_body_id",
                table: "ExportOrder",
                column: "exporder_body_id",
                principalTable: "ExportBillbody",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportOrder_SlotInfo_exporder_slot_code",
                table: "ExportOrder",
                column: "exporder_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportStock_GoodsInfo_expstock_goods_id",
                table: "ExportStock",
                column: "expstock_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportStock_SlotInfo_expstock_slot_code",
                table: "ExportStock",
                column: "expstock_slot_code",
                principalTable: "SlotInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExportStock_WarehouseInfo_expstock_warehouse_id",
                table: "ExportStock",
                column: "expstock_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportStock_GoodsInfo_impstock_goods_id",
                table: "ImportStock",
                column: "impstock_goods_id",
                principalTable: "GoodsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImportStock_WarehouseInfo_impstock_warehouse_id",
                table: "ImportStock",
                column: "impstock_warehouse_id",
                principalTable: "WarehouseInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
